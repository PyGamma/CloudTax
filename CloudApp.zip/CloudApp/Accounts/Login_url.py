from django.conf.urls import url
from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import UserCreationForm
from . import views
import africastalking



urlpatterns = [
	url(r'^$', views.index),
	url(r'^login', LoginView.as_view(), name='login'),
	url(r'^secure_redirect', views.secure_redirect, name='secure_redirect'),
	url(r'^logout$', LoginView.as_view(), name='logout'),
	url(r'^signup$', views.signup, name='signup'),
	url(r'^notify_someone$', views.notify_someone, name='notify_someone'),

]

