from django.contrib import admin
from Accounts.models import  UserProfile


class UserProfileAdmin(admin.ModelAdmin):
	list_display = ('id', 'user', 'user_office', 'office_tag')
	list_filter = ('id', 'user', 'user_office', 'office_tag')

# Register your models here.

admin.site.register(UserProfile, UserProfileAdmin)
