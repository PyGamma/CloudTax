
from django import forms
from django.contrib.auth.models import User
from Accounts.models import UserProfile
from django.contrib.auth.Users import UserCreationForm
#this form handles the user creation form and user  prifile creations  form

class UserForm(forms.ModelForm):
	class Meta:
		model = User
		fields = ('username', 'email', 'password', 'first_name', 'last_name')	

class UserProfileForm(forms.ModelForm):
	class Meta:
		model  = UserProfile
		fields = ('user_office', 'office_tag', 'Municpality' )
		

class UserRegisterForm(UserCreationForm):
	email = forms.EmailField()
	FirstName = forms.CharField()
	LastName = forms.CharField()

	class meta:
		model = Users
		Field = ['username', 'FirstName', 'LastName', 'email', 'password1', 'password2']


		