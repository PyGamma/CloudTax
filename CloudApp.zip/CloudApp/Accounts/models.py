from django.contrib.sites.models import Site
from django.contrib.auth.models import User
from django.db import models
from django.forms import ModelForm

# Create your models here.

class UserProfile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	#picture = models.ImageField(upload_to='profile_image', blank=True)
	user_office = models.CharField(max_length=200, blank=True)
	office_tag = models.CharField(max_length=200, blank=True)
	def __str__(self):
		return self.user.username


 