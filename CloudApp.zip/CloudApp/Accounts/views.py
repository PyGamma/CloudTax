from django.shortcuts import render, redirect
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.http import QueryDict
from Accounts.models import UserProfile
from django.contrib.auth.models import User
import africastalking

#---------------------------------------------------------------------

def notify_someone(request):
	username = "dreamstechnologies"
	apikey = "84b4fed4aacc314df3f4f7e09195d92ccb9dde2a5b004eb28738f841df88e01e"

	#Initialize the SDK
	africastalking.initialize(username, apikey)

	#Get the SMS service
	sms = africastalking.SMS

	#Define some options that we will use to send the SMS
	recipients = ['+256784164470']
	message = 'Hallo, this is a test meesage for some SMS API'
	sender = '+256785547653'

	#Send the SMS
	try:
	    #Once this is done, that's it! We'll handle the rest
	    response = sms.send(message, recipients, sender)
	    print(response)
	except Exception as e:
	    print(f"Houston, we have a problem {e}")
	return render(request, 'index.html')

def index(request):
	return render(request, 'index.html')


def login(request):
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username= username, password=password)
		if user is not None:
			login(request)
			#The below render function needs to be be turn to a redirect function in the near future..
			return redirect('/DivisionPlan/panel/', {'username': username})
		else:
			form = AuthenticationForm()
			return render(request, 'Registration/login.html')
	else:
		form = AuthenticationForm()
		return render(request, 'Registration/login.html', {'form': form})


def secure_redirect(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	if redirect_office=="Division Planing": 
		return redirect('/DivisionPlan/') 
		#return render(request, 'DivisionPlan/panel.html', {'designation': designation})
	elif redirect_office=="Division Taxation":
		return redirect('/DivisionTax/')
	elif redirect_office == "Municipal Planning":
		return redirect('/MunicipalPlan/')
	elif redirect_office == "Municipal Valuation":
		return redirect('/MunicipalValuation/')
	elif redirect_office == "Municpal Taxation":
		return redirect('/MunicipalTaxation/')
	elif redirect_office == "Tax Enforcement":
		return redirect('/DivisionPlan/')		
	else:
		messages = "Access Denied! Please contact system administartor for more help."
		return render(request, 'Registration/login.html', {'designation': designation})
		
		
#------------------------------------------------------------------------------
#This section is used for the User Registrationn Form

def signup(request):
	if request.method == 'POST':
		user_form = UserForm(data=request.POST)
		profile_form = UserProfileForm(data=request.POST) 
		#if user.is_valid():
		user = user_form.save()
		user.set_password(user.password)
		user.save()
		profile = profile_form.save(commit=False)
		profile.user = user
		profile.save()
		return render(request, 'Registration/login.html')
		#return render(request, 'Registration/signup.html', {'form' : form})
	else:
		form1 = UserForm()
		form2 = UserProfileForm()
		return redirect('Accounts')


