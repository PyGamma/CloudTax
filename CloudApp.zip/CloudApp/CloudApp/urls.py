from django.contrib import admin
from django.conf.urls import url
from django.urls import path
from django.urls import include
from . import views


urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^accounts/', include('Accounts.Login_url')),
    url(r'^DivisionPlan/',  include('DivisionPlaning.DivPlan_url')),
    url(r'^DivisionTax/',  include('DivisionTaxation.DivTax_url')),
    url(r'^MunicipalPlan/', include('MunicipalPlan.MunPlan_url')),
    url(r'^MunicipalValuation/', include('MunicipalValuation.MunValue_url')),
    url(r'^MunicipalTaxation/', include('MunicipalTaxation.MunTax_url')),
    url(r'^DivisionPlan/panel', views.panel)
]
