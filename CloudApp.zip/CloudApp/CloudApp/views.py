from django.shortcuts import render, redirect
from Accounts.models import UserProfile



def panel(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/panel.html', 	{'designation': designation})