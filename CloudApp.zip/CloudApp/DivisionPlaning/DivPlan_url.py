from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$',  views.index),
	url(r'^applicant$', views.applicant),
	url(r'^add_applicant$', views.add_applicant),
	url(r'^add_application$', views.add_application),
	url(r'^view_application$', views.view_application),
	url(r'^view_applicant$', views.view_applicant),
	url(r'^schedules$', views.schedules),
	url(r'^view_schedules$', views.view_schedules),
	url(r'^add_schedules$', views.add_schedules),
	url(r'^notify_someone$', views.notify_someone),
	url(r'^report$', views.report),
	url(r'^add_report$', views.add_report),
	url(r'^pdf_view', views.InspectionForm.as_view()),
	url(r'^get_property', views.get_property),
	url(r'^pro_property$', views.pro_property),
	url(r'^add_property$', views.add_property),
	url(r'^view_property$', views.view_property)

]













