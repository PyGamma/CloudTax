from django.contrib import admin
from DivisionPlaning.models import *

class ApplicantAdmin(admin.ModelAdmin):
	list_display = ('nin_pin', 'surname',  'first_name', 'given_name', 'sex', 'telephone',
		'valuation_tell', 'email_id', 'specification', 'security_tag')
	list_filter = ('nin_pin', 'surname',  'first_name', 'given_name', 'sex', 'telephone',
		'valuation_tell', 'email_id', 'specification', 'security_tag')


class ApplicationAdmin(admin.ModelAdmin):
	list_display = ('id','application_date', 'Update_date',  'property_type', 'status', 'start_date', 'completion_date', 
		'estimated_value', 'engineer_reg', 'applicant', 'properties', 'security_tag')
	list_filter = ('id', 'application_date', 'Update_date',  'property_type', 'status', 'start_date', 'completion_date', 
		'estimated_value', 'engineer_reg', 'applicant', 'properties', 'security_tag')



class SchedulesAdmin(admin.ModelAdmin):
	list_display = ('i_code', 'i_type', 'inspection_date', 'inspection_time', 'i_status', 'engineer_reg', 'security_tag')
	list_display = ('i_code', 'i_type', 'inspection_date', 'inspection_time', 'i_status', 'engineer_reg', 'security_tag')

class ReportAdmin(admin.ModelAdmin):
	list_display = ('RepCode', 'RepDate', 'Type', 'Report_File', 'inspection', 'security_tag')
	list_filter = ('RepCode', 'RepDate', 'Type', 'Report_File', 'inspection', 'security_tag')


class PropertyAdmin(admin.ModelAdmin):
	list_display = ('pro_id', 'division', 'ward', 'road', 'plotnumber', 'building_permit_no',
		'tax_code', 'applicant', 'security_tag')
	list_filter = ('pro_id', 'division', 'ward', 'road', 'plotnumber', 'building_permit_no',
		'tax_code', 'applicant', 'security_tag')

	
class TestlAdmin(admin.ModelAdmin):
	list_display = ('id', )
	list_filter = ('id',)


class PermitAdmin(admin.ModelAdmin):
	list_display = ('permNo', 'issueDate', 'permtype', 'occurance', 'status','properties', 'security_tag')
	list_filter = ('permNo', 'issueDate', 'permtype', 'occurance', 'status', 'properties', 'security_tag')


class TaxRegisterAdmin(admin.ModelAdmin):
	list_display = ('reg_date', 'status', 'tax_code', 'perm_id', 'properties', 'security_tag')
	list_filter = ('reg_date', 'status', 'tax_code', 'perm_id', 'properties', 'security_tag')

class TaxValueAdmin(admin.ModelAdmin):
	list_display = ('p_key', 'v_date', 'value', 'v_status', 'properties', 'security_tag')
	list_filter = ('p_key', 'v_date', 'value', 'v_status', 'properties', 'security_tag')

class ComplaintsAdmin(admin.ModelAdmin):
	list_display = ('comp_id', 'c_data', 'status', 'properties', 'TaxValue', 'security_tag')
	list_filter = ('comp_id', 'c_data', 'status','properties', 'TaxValue', 'security_tag')

class CourtScheduleAdmin(admin.ModelAdmin):
	list_filter = ('court_id', 'cort_date', 'inspection_time', 'status', 'properties', 'Tribunal', 'security_tag')
	list_display = ('court_id', 'cort_date', 'inspection_time', 'status', 'properties', 'Tribunal', 'security_tag')


# Register your models here.
admin.site.register(Applicant, ApplicantAdmin)
admin.site.register(Application, ApplicationAdmin)
admin.site.register(properties, PropertyAdmin)
admin.site.register(Schedules, SchedulesAdmin)
admin.site.register(Report, ReportAdmin)
admin.site.register(Permit, PermitAdmin)
admin.site.register(TaxRegister, TaxRegisterAdmin)
admin.site.register(TaxValue, TaxValueAdmin)
admin.site.register(Tribunal, ComplaintsAdmin)
admin.site.register(CourtSchedule, CourtScheduleAdmin)
