from django import forms
from DivisionPlaning.models import Applicant, properties, Application, Schedules, Report
#this form handles the user creation form and user  prifile creations  form




class ApplicantForm(forms.ModelForm):
	class Meta:
		model = Applicant
		fields = ('nin_pin', 'surname', 'first_name', 'given_name', 'sex', 'telephone', 'valuation_tell', 
			'email_id', 'specification')	

