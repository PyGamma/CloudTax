from django.db import models
	

class Applicant(models.Model):
	nin_pin = models.CharField(primary_key=True, max_length=50)
	surname = models.CharField(max_length=100)
	first_name = models.CharField(max_length=100)
	given_name = models.CharField(max_length=100)
	sex = models.CharField(max_length=6)
	telephone = models.CharField(max_length=20)
	valuation_tell = models.CharField(max_length=20)
	email_id = models.CharField(max_length=200)
	specification = models.CharField(max_length=100)
	security_tag = models.CharField(max_length=20, default='ADMIN')

	def __str__(self):
		return self.nin_pin


class properties(models.Model):
	pro_id = models.CharField(primary_key=True, max_length=50)
	division = models.CharField(max_length=100)
	ward = models.CharField(max_length=100)
	road = models.CharField(max_length=100)
	plotnumber = models.CharField(max_length=6)
	status = models.CharField(max_length=25, default="Pending")
	building_permit_no = models.CharField(max_length=20)
	tax_code = models.CharField(max_length=20)
	applicant = models.ForeignKey('Applicant', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')

	def __str__(self):
		return self.pro_id


class Application(models.Model):
	application_date = models.DateTimeField(auto_now_add=True)
	Update_date = models.DateTimeField(auto_now=True)
	property_type = models.CharField(max_length=100)
	status = models.CharField(max_length=100)
	start_date = models.DateField(max_length=50)
	completion_date = models.DateField(max_length=100)
	estimated_value = models.CharField(max_length=100)
	engineer_reg = models.CharField(max_length=100)
	applicant = models.ForeignKey('Applicant', models.SET_NULL, null=True, blank=True)
	properties = models.ForeignKey('properties', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')

	def __str__(self):
		return self.status


class Schedules(models.Model):
	i_code = models.CharField(primary_key=True, max_length=100)
	i_type = models.CharField(max_length=100)
	inspection_date = models.DateField(max_length=100)
	inspection_time = models.CharField(max_length=100)
	i_status = models.CharField(max_length=50)
	engineer_reg = models.CharField(max_length=100)
	properties = models.ForeignKey('properties', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')




class Report(models.Model):
	RepCode = models.CharField(primary_key=True, max_length=100)
	RepDate = models.DateField(auto_now=True)
	Type = models.CharField(max_length=100)
	Report_File = models.CharField(max_length=50)
	inspection = models.ForeignKey('Schedules', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')

class Permit(models.Model):
	permNo = models.CharField(primary_key=True, max_length=100)
	issueDate = models.DateField(auto_now_add=True)
	#Validity = models.DateField(max_length=100)
	permtype = models.CharField(max_length=25)
	status = models.CharField(max_length=25, default="Not Issued")
	occurance = models.CharField(max_length=6, default="1")
	properties = models.ForeignKey('properties', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')


class TaxRegister(models.Model):
	reg_date = models.DateTimeField(auto_now_add=True)
	status = models.CharField(max_length=25, default="Pending")
	tax_code = models.CharField(max_length=20)
	perm_id = models.CharField(max_length=20)
	properties = models.ForeignKey('properties', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')

	def __str__(self):
		return self.status


class TaxValue(models.Model):
	p_key = models.AutoField(primary_key=True)
	v_date = models.DateTimeField(auto_now_add=True)
	value = models.CharField(max_length=25)
	v_status = models.CharField(max_length=20, default="Unresolved")
	properties = models.ForeignKey('properties', models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')


class Tribunal(models.Model):
	comp_id = models.AutoField(primary_key=True)
	c_data = models.DateField(auto_now=True)
	status = models.CharField(max_length=10, default="Pending")
	properties = models.ForeignKey(properties, models.SET_NULL , null=True)
	TaxValue = models.ForeignKey(TaxValue, models.SET_NULL, null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')


class CourtSchedule(models.Model):
	court_id = models.CharField(max_length=100, primary_key=True)
	cort_date = models.DateField(max_length=100)
	inspection_time = models.CharField(max_length=100)
	status = models.CharField(max_length=100, default="Pending")
	properties = models.ForeignKey(properties, models.SET_NULL, null=True, blank=True)
	Tribunal = models.ForeignKey(Tribunal, models.SET_NULL , null=True, blank=True)
	security_tag = models.CharField(max_length=20, default='ADMIN')


	def __str__(self):
		return self.court_id