from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from DivisionPlaning.forms import ApplicantForm
from django.contrib import messages
from django.http import HttpResponse
from django.views import View 
from DivisionPlaning.models import Applicant, Application, properties, Schedules, Report, Permit
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa
from Accounts.models import UserProfile



@login_required
def index(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/panel.html' , {'designation': designation})

@login_required
def applicant(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	form = ApplicantForm()
	return render(request, 'DivisionPlan/start.html', {'form': form, 'designation': designation})

@login_required
def add_applicant(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	#This section of code fetch the data for individual type owner data to save in the individual table
	nin_pin = request.POST.get("nin_pin")
	surname = request.POST.get("surname")
	f_name = request.POST.get("f_name")
	g_name = request.POST.get("g_name")
	gender = request.POST.get("gender")
	ownership = request.POST.get("ownership")
	email_id = request.POST.get("email_id")
	telephone = request.POST.get("telephone")
	contact = request.POST.get("contact")
	key = nin_pin

	applicant1 = Applicant(nin_pin=nin_pin, surname=surname, first_name=f_name, given_name=g_name, 
		sex=gender, security_tag=designation, telephone=telephone, valuation_tell=contact, email_id=email_id, specification=ownership)
	applicant1.save()
	return render(request, 'DivisionPlan/property.html', {'key': key, 'designation': designation})


@login_required
def pro_property(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/property.html', {'designation': designation})


@login_required
def add_property(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	applicant_key = request.POST.get("applicant_id")
	Property_number = request.POST.get("Property_number")
	division = request.POST.get("division")
	tax_code = request.POST.get("tax_code")
	ward = request.POST.get("ward")
	buildpermit = request.POST.get("buildpermit")
	road = request.POST.get("road")
	plot_number = request.POST.get("plot_number")
	applicant1 = Applicant.objects.all()
	for i in applicant1:
		if i.nin_pin == applicant_key:
			foreign_applicant = i
	instance = properties(pro_id=Property_number, division=division, ward=ward, road=road,
		plotnumber=plot_number, security_tag=designation, tax_code=tax_code, building_permit_no=buildpermit)
	instance.save()
	instance.applicant_id = foreign_applicant
	instance.save()
	return render(request, 'DivisionPlan/register.html', {'foreign_applicant': foreign_applicant, 'designation': designation})


@login_required
def view_property(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = properties.objects.filter(security_tag=designation)
	context= {'data': data, 'designation': designation}
	return render(request, 'DivisionPlan/propertyView.html', context)	


@login_required
def add_application(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	property_type = request.POST.get("pro_type")
	status = "Pending" 
	start_date = request.POST.get("start_date")
	estimated_value = request.POST.get("pro_estimate")
	completion_date =  request.POST.get("completion_date")
	engineer_reg = request.POST.get("eng_cert")
	applicant_key = request.POST.get("applicant_id")
	applicant1 = Applicant.objects.all()
	properties1 = properties.objects.all()
	for i in applicant1:
		if i.nin_pin == applicant_key:
			foreign_applicant = i

	for i in properties1:
		if i.applicant_id == applicant_key:
			foreign_property = i

	app_instance = Application( property_type=property_type, status= status, 
		start_date=start_date, security_tag=designation, estimated_value= estimated_value, completion_date=completion_date, 
		engineer_reg= engineer_reg)
	app_instance.save() 
	app_instance.applicant_id = foreign_applicant
	app_instance.properties_id = foreign_property
	app_instance.save()
	form = ApplicantForm()
	return render(request, 'DivisionPlan/start.html', {'form': form, 'designation': designation})


@login_required
def view_application(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Application.objects.filter(security_tag=designation, status="Pending")
	context= {'data': data, 'designation': designation}
	return render(request, 'DivisionPlan/applicationView.html', context)


@login_required
def view_applicant(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Applicant.objects.filter(security_tag=designation)
	context = {'data': data, 'designation': designation}
	return render(request, 'DivisionPlan/applicantView.html', context)



@login_required
def schedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/schedules.html', {'designation': designation})


@login_required
def add_schedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	i_code = request.POST.get("i_code")
	i_type = "Site Visit"
	inspection_date = request.POST.get("inspection_date")
	inspection_time = request.POST.get("inspection_time")
	i_status = request.POST.get("i_status")
	engineer_reg = request.POST.get("eng_cert")
	property_key = request.POST.get("pro_id")
	property1 = properties.objects.all()
	for i in property1:
		if i.pro_id == property_key:
			foreign_property = i

	application1 = Application.objects.filter(properties_id=property_key, security_tag=designation)
	for i in application1:
		foreign_application = i
	schedules_instance = Schedules(i_code=i_code, i_type=i_type, inspection_date=inspection_date, inspection_time=inspection_time, 
		i_status=i_status, security_tag=designation, engineer_reg=engineer_reg)
	schedules_instance.save()
	schedules_instance.properties_id = foreign_property
	schedules_instance.save()
	foreign_application.status = "Progress"
	foreign_application.save()
	return render(request, 'DivisionPlan/schedules.html', {'designation': designation})


@login_required
def view_schedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Schedules.objects.filter(i_type="Site Visit", security_tag=designation, i_status="progress")
	context= {'data': data, 'designation': designation}
	return render(request, 'DivisionPlan/schedulesView.html', context)



@login_required
def notify_someone(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	Subject = "SiteVisit"
	send_mail(Subject,'Message.', 'angelgammarays@gmail.com', ['raisben7@gmail.com', 'raisben7@gmail.com'],)

@login_required
def get_property(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/getProperty.html', {'designation': designation})


def render_to_pdf  (template_src, context_dict={}):
	template = get_template(template_src)
	html = template.render(context_dict)
	result = BytesIO()
	pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
	if not pdf.err:
		return HttpResponse(result.getvalue(), content_type='application/pdf')
	return None 

class InspectionForm(View):
	def get(self, request, *args, **kwargs):
		property_no = request.GET.get("property_no")
		pdfchoice = request.GET.get("pdfchoice")
		property_instance = properties.objects.filter(pro_id=property_no)
		for i in property_instance:
			foreign_property = i
		owner_instance = Applicant.objects.filter(nin_pin=foreign_property.applicant_id)
		for i in owner_instance:
			foreign_owner = i
		choice1 = "Inspection Value"
		if pdfchoice == choice1:	
			pdf = render_to_pdf('DivisionPlan/inspectionForm.html', {'foreign_property': foreign_property,
				'foreign_owner': foreign_owner })
		else:
			pdf = render_to_pdf('DivisionPlan/BuildingPermit.html', {'foreign_property': foreign_property,
				'foreign_owner': foreign_owner})
		return HttpResponse(pdf, content_type='application/pdf')
#-------------------------------------------------------------------------

#This sections of code is used to configure the report management modules views.

@login_required
def report(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionPlan/report.html', {'designation': designation})


@login_required	
def add_report(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	RepCode = request.POST.get("RepCode")
	RepDate = request.POST.get("RepDate") 
	Type = "Site Visit Report"
	Report_File = request.POST.get("report_file")
	inspection_key = request.POST.get("InsCode")

	inspection1 = Schedules.objects.filter(security_tag=designation)
	for i in inspection1:
		if i.i_code == inspection_key:
			foreign_inspection = i
			property_key = foreign_inspection.properties_id

	key_pro = properties.objects.filter(pro_id=property_key)
	for i in key_pro:
		key_property = i

	application1 = Application.objects.filter(properties_id=property_key)
	for i in application1:
		foreign_application = i

	report_instance = Report(RepCode=RepCode, security_tag=designation, RepDate=RepDate, Type=Type, Report_File=Report_File)
	report_instance.save()
	report_instance.inspection_id = foreign_inspection
	report_instance.save()
	foreign_inspection.i_status="Completed"
	foreign_application.status = "Approved"
	foreign_application.save()
	foreign_inspection.save()

	return render(request, 'DivisionPlan/report.html', {'designation': designation})

	