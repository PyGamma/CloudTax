from django.conf.urls import url
from . import views



urlpatterns = [
	url(r'^$',  views.index),
	url(r'^panel$',  views.index),
	url(r'^task$', views.pending_task),
	url(r'^waiting_reg$', views.waiting_reg),
	url(r'^iniateProperty$', views.iniateProperty),
	url(r'^initiating$', views.initiating),
	url(r'^get_permit_details$', views.permit_property),
	url(r'^pdf_view$', views.InspectionForm.as_view()),
	url(r'^test$', views.test),


]

