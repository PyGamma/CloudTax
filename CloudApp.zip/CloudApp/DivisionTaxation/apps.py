from django.apps import AppConfig


class DivisiontaxationConfig(AppConfig):
    name = 'DivisionTaxation'
