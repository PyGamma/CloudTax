from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
from DivisionPlaning.models import Applicant, Application, properties, Schedules, Report
from Accounts.models import UserProfile
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa


# Create your views here.
def index(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionTax/panel.html', {'designation': designation})

def pending_task(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	task = Application.objects.filter(status='Approved', security_tag=designation)
	return render(request, 'DivisionTax/pendingTask.html', {'task': task, 'designation': designation})

def waiting_reg(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	task = Application.objects.filter(status='Completed', security_tag=designation)
	return render(request, 'DivisionTax/waitingReg.html', {'task': task, 'designation': designation})

def permit_property(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionTax/getProperty.html',{'designation': designation})

def iniateProperty(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionTax/iniateProperty.html', {'designation': designation})

def initiating(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	property_no = request.POST.get("property_no")
	app1 = Application.objects.filter(properties_id=property_no, security_tag=designation)
	for i in app1:
		foreign_app1 = i
	foreign_app1.status = "Initiated"
	foreign_app1.save()
	return render(request, 'DivisionTax/iniateProperty.html', {'designation': designation})
	


def render_to_pdf  (template_src, context_dict={}):
	template = get_template(template_src)
	html = template.render(context_dict)
	result = BytesIO()
	pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
	if not pdf.err:
		return HttpResponse(result.getvalue(), content_type='application/pdf')
	return None 


class InspectionForm(View):
	def get(self, request, *args, **kwargs):

		user = request.user
		redirect_tag = UserProfile.objects.filter(user=user)
		for i in redirect_tag:
			redirect_office = i.user_office
			designation = i.office_tag
		property_no = request.GET.get("property_no")
		app1 = Application.objects.filter(properties_id=property_no)
		for i in app1:
			app_key = i
		pdfchoice = request.GET.get("pdfchoice")
		property_instance = properties.objects.filter(pro_id=property_no)
		for i in property_instance:
			foreign_property = i
		owner_instance = Applicant.objects.filter(nin_pin=foreign_property.applicant_id)
		for i in owner_instance:
			foreign_owner = i
		pdf = render_to_pdf('DivisionTax/BuildingPermit.html', {'foreign_property': foreign_property,
			'foreign_owner': foreign_owner})
		app_key.status = "Completed"
		app_key.save()
		return HttpResponse(pdf, content_type='application/pdf')


def test(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'DivisionTax/index.html', {'designation': designation})