from django.conf.urls import url
from . import views



urlpatterns = [
	url(r'^$',  views.index),
	url(r'^panel$',  views.index),
	url(r'^reg_list$',  views.register),
	url(r'^register$', views.registration),
	url(r'^preview_dtails$', views.preview_dtails),
	url(r'^sheduleing_list$', views.waiting_shedules),
	url(r'^sheduels_detail$', views.sheduels_detail),
	url(r'^add_shedules$', views.add_shedules),
	url(r'^shedules$', views.shedules),
	url(r'^shedules_action$', views.shedules_action),
	url(r'^execute$', views.execute),
	url(r'^report_list$', views.report_list),
	url(r'^preadd_report$', views.preadd_report),
	url(r'^add_report$', views.add_report),
]

