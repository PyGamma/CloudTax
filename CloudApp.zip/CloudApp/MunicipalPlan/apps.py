from django.apps import AppConfig


class MunicipalplanConfig(AppConfig):
    name = 'MunicipalPlan'
