from django.db import models
from DivisionPlaning.models import Applicant, Application, properties, Schedules, Report

# Create your models here.

