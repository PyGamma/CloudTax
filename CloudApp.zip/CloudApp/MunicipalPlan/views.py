from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
from DivisionPlaning.models import Applicant, Application, properties, Schedules, Report, TaxRegister
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa
from Accounts.models import UserProfile



def index(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'MunicipalPlan/panel.html', {'designation':designation} )


def register(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Application.objects.filter(status="Initiated", security_tag=designation)
	return render(request, 'MunicipalPlan/reg_list.html', {'data': data, 'designation':designation})


def preview_dtails(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("key")
	Pro_detail = properties.objects.filter(pro_id=pro_key, security_tag=designation)
	for i in Pro_detail:
		app_key = i.applicant_id
	app_detail = Applicant.objects.filter(nin_pin=app_key, security_tag=designation)
	return render(request, 'MunicipalPlan/detail_preview.html', { 'designation':designation, 'Pro_detail': Pro_detail, 'app_detail': app_detail})


def registration(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	nin_pin = request.POST.get("nin_pin")
	pro_id = request.POST.get("pro_id")
	tax_code = request.POST.get("tax_code")
	email_id = request.POST.get("email_id")
	building_permit_no = request.POST.get("building_permit_no")
	telepone = request.POST.get("telepone")
	contact = request.POST.get("contact")
	option = request.POST.get("option1")
	data = Application.objects.filter(status="Initiated", security_tag=designation)
	if option == "No Update":
		registration_instance = TaxRegister(tax_code=tax_code, perm_id=building_permit_no, security_tag=designation)
		registration_instance.save()
		registration_instance.properties_id = pro_id
		registration_instance.save()
		last_key = Application.objects.filter(properties_id=pro_id, security_tag=designation)
		for i in last_key:
			key = i
			key.status = "Done"
			key.save()
		return render(request, 'MunicipalPlan/reg_list.html', {'data': data, 'designation':designation})
	else:
		app_key = Applicant.objects.filter(nin_pin=nin_pin, security_tag=designation)
		pro_key = properties.objects.filter(pro_id=pro_id, security_tag=designation)
		last_key = Application.objects.filter(properties_id=pro_id, security_tag=designation)
		for i in app_key:
			updates1 = i
			updates1.telephone = telepone
			updates1.valuation_tell = contact
			updates1.email_id = email_id
			updates1.save()
		for i in pro_key:
			updates2 = i 
			updates2.tax_code = tax_code
			updates2.save()
		for i in last_key:
			key = i
			key.status = "Done"
			key.save()
		registration_instance = TaxRegister(tax_code=tax_code, perm_id=building_permit_no, security_tag=designation)
		registration_instance.save()
		registration_instance.properties_id = pro_id
		registration_instance.save()
		return render(request, 'MunicipalPlan/reg_list.html', {'data': data, 'designation':designation})


def waiting_shedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = TaxRegister.objects.filter(status="Pending", security_tag=designation)
	return render(request, 'MunicipalPlan/sheduleing_list.html', {'data': data, 'designation':designation})


def sheduels_detail(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	key = request.POST.get("key")
	return render(request, 'MunicipalPlan/sheduels_detail.html', {'key': key, 'designation':designation})


def add_shedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	i_code = request.POST.get("i_code")
	inspection_date = request.POST.get("inspection_date")
	inspection_time = request.POST.get("inspection_time")
	i_status = request.POST.get("i_status")
	eng_cert = request.POST.get("eng_cert")
	pro_id = request.POST.get("pro_id")

	Pro_instance = properties.objects.filter(pro_id=pro_id, security_tag=designation)
	for i in Pro_instance:
		foreign_pro = i
	shedule_instance = Schedules(i_code=i_code, security_tag=designation, i_type="Property Viewing", inspection_date=inspection_date, 
		inspection_time=inspection_time, i_status=i_status, engineer_reg=eng_cert)
	shedule_instance.save()
	shedule_instance.properties = foreign_pro
	shedule_instance.save()
	data = TaxRegister.objects.filter(status="Pending", security_tag=designation)

	tax_instance = TaxRegister.objects.filter(properties_id=pro_id, security_tag=designation)
	for i in tax_instance:
		foreign_tax = i
		foreign_tax.status = "Progress"
		foreign_tax.save()
	return render(request, 'MunicipalPlan/sheduleing_list.html', {'data': data, 'designation':designation})



def shedules(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	context = Schedules.objects.filter(i_status="progress", i_type="Property Viewing", security_tag=designation)
	return render(request, 'MunicipalPlan/shedules.html', {'context': context, 'designation':designation})


def shedules_action(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	key = request.POST.get("key")
	data = Schedules.objects.filter(i_code=key, i_type="Property Viewing", security_tag=designation)
	return render(request, 'MunicipalPlan/shedules_action.html', {'data': data, 'designation':designation})


def execute(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	i_key = request.POST.get("i_code")
	context = Schedules.objects.filter(i_status="progress", i_type="Property Viewing", security_tag=designation)
	shedule_instance = Schedules.objects.filter(i_code=i_key, security_tag=designation)
	for i in shedule_instance:
		change_she = i
		change_she.i_status = "Executed"
		change_she.save()
	return render(request, 'MunicipalPlan/shedules.html', {'context': context, 'designation':designation})


def report_list(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Schedules.objects.filter(i_status="Executed", security_tag=designation)
	return render(request, 'MunicipalPlan/report_list.html', {'data': data, 'designation':designation})


def preadd_report(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	sc_id = request.POST.get("key")
	return render(request, 'MunicipalPlan/preview_report.html', {'sc_id':sc_id, 'designation':designation})


def add_report(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	RepCode = request.POST.get("RepCode")
	Type = "Property Viewing Report"
	Report_File = request.POST.get("report_file")
	InsCode = request.POST.get("InsCode")
	data = Schedules.objects.filter(i_status="Executed", security_tag=designation)
	for_ins = Schedules.objects.filter(i_code=InsCode, i_type="Property Viewing", security_tag=designation)
	for i in for_ins:
		for_key = i
	ins_key = Schedules.objects.filter(i_code=InsCode, security_tag=designation)
	for i in ins_key:
		key = i
	report_instance = Report(RepCode=RepCode, security_tag=designation, Type=Type, Report_File=Report_File)
	report_instance.save()
	report_instance.inspection_id = key
	report_instance.save()
	for_key.i_status = "Completed"
	for_key.save()
	return render(request, 'MunicipalPlan/report_list.html', {'data': data, 'designation':designation})
