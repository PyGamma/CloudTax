from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^panel$', views.index),
    url(r'^uncleared_dues$', views.uncleared_dues),
    url(r'^payment_details$', views.payment_details),
    url(r'^defaulter_list$', views.defaulter_list),
    url(r'^enforcement_list$', views.enforcement_list),
    url(r'^permit_list$', views.permit_list),
    
    
  
]
