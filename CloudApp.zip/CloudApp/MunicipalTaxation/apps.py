from django.apps import AppConfig


class MunicipaltaxationConfig(AppConfig):
    name = 'MunicipalTaxation'
