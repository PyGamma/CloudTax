from django.shortcuts import render

# Create your views here.


def index(request):
	return render(request, 'MunicipalTax/panel.html')


def uncleared_dues(request):
	data = ""
	return render(request, 'MunicipalTax/uncleared_dues.html', {'data': data})



def payment_details(request):
	data = ""
	return render(request, 'MunicipalTax/payment_details.html', {'data': data})


def defaulter_list(request):
	data = ""
	return render(request, 'MunicipalTax/defaulter_list.html', {'data': data})


def enforcement_list(request):
	data = ""
	return render(request, 'MunicipalTax/enforcement_list.html', {'data': data})


def permit_list(request):
	data = ""
	return render(request, 'MunicipalTax/permit_list.html', {'data':data})
