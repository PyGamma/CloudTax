from django.conf.urls import url
from . import views



urlpatterns = [
	url(r'^$',  views.index),
	url(r'^panel$', views.index),
	url(r'^valuate_list$', views.valuate_list),
	url(r'^pre_valuate$', views.pre_valuate),
	url(r'^valuate$', views.valuate),
	url(r'^unresolved$', views.unresolved),
	url(r'^add_tribunal$', views.add_tribunal),
	url(r'^pending_tribunal$', views.pending_tribunal),
	url(r'^schedule_hearing$', views.schedule_hearing),
	url(r'^add_hearing$', views.add_hearing),
	url(r'^pending_approval$', views.pending_approval),
	url(r'^approval$', views.approval),
	url(r'^certifications$', views.certifications),
	url(r'^issue_certificate', views.issue_certificate),
]