from django.apps import AppConfig


class MunicipalvaluationConfig(AppConfig):
    name = 'MunicipalValuation'
