from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
#from DivisionPlaning.models import Applicant, Application, Tribunal, properties, Schedules, Report, TaxRegister, TaxValue
from DivisionPlaning.models import *
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa
from Accounts.models import UserProfile

# Create your views here.
def index(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return render(request, 'MunValuation/panel.html', {'designation':designation})


def valuate_list(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = Schedules.objects.filter(i_status="Completed", i_type="Property Viewing", security_tag=designation)
	return render(request, 'MunValuation/valuate_list.html', {'data': data, 'designation':designation})


def pre_valuate(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("pro_key")
	ins_key = request.POST.get("in_key")
	return render(request, 'MunValuation/pre_valuate.html', {'pro_key': pro_key, 'ins_key': ins_key, 'designation':designation})

def valuate(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("pro_key")
	value = request.POST.get("value")
	fore_key = properties.objects.filter(pro_id=pro_key, security_tag=designation)
	for i in fore_key:
		fore_pro = i
	for_ins = Schedules.objects.filter(properties_id=pro_key, security_tag=designation, i_type="Property Viewing")
	for i in for_ins:
		for_key = i
	valuate_ins = TaxValue(value=value, properties=fore_pro, security_tag=designation)
	valuate_ins.save()
	for_key.i_status = "Achieved"
	for_key.save()
	data = Schedules.objects.filter(i_status="Completed", i_type="Property Viewing", security_tag=designation)
	return render(request, 'MunValuation/valuate_list.html', {'data': data, 'designation':designation})


def unresolved(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	context = TaxValue.objects.filter(v_status="Unresolved", security_tag=designation)
	return render(request, 'MunValuation/unresolved.html', {'context': context, 'designation':designation})


def add_tribunal(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("pro_key")
	context = TaxValue.objects.filter(v_status="Unresolved", security_tag=designation)
	fore_pro = properties.objects.filter(pro_id=pro_key, security_tag=designation)
	for i in fore_pro:
		pro_ins = i
	taxvalue1 = TaxValue.objects.filter(properties_id=pro_key, security_tag=designation)
	for i in taxvalue1:
		foreign_value = i

	tribunal_instance = Tribunal(properties=pro_ins, security_tag=designation, TaxValue=foreign_value)
	tribunal_instance.save()
	foreign_value.v_status = "Pending"
	foreign_value.save()
	return render(request, 'MunValuation/unresolved.html', {'context': context, 'designation':designation})


def pending_tribunal(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data =  Tribunal.objects.filter(status="Pending", security_tag=designation)
	return render(request, 'MunValuation/pending_tribunal.html', {'data': data, 'designation':designation})


def schedule_hearing(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("pro_key")
	tax_key = request.POST.get("tax_key")
	return render(request, 'MunValuation/schedule_hearing.html', {'pro_key': pro_key, 'tax_key':tax_key, 'designation':designation})


def add_hearing(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	i_code = request.POST.get("i_code")
	in_date = request.POST.get("inspection_date")
	in_time = request.POST.get("inspection_time")
	tax_key = request.POST.get("tax_key")
	pro_key = request.POST.get("pro_key")
	foreign_tri = Tribunal.objects.filter(TaxValue_id=tax_key, security_tag=designation)
	for i in foreign_tri:
		tribunal_instance = i
	fore_pro = properties.objects.filter(pro_id=pro_key, security_tag=designation)
	for i in fore_pro:
		foreign_pro = i
	hearing =  CourtSchedule(court_id=i_code, cort_date=in_date,inspection_time=in_time, 
		properties=foreign_pro, Tribunal=tribunal_instance, security_tag=designation)
	hearing.save()
	tribunal_instance.status = "Progress"
	tribunal_instance.save()
	data =  Tribunal.objects.filter(status="Pending", security_tag=designation)
	return render(request, 'MunValuation/pending_tribunal.html', {'data': data, 'designation':designation})

def pending_approval(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = CourtSchedule.objects.filter(status="Pending", security_tag=designation)
	return render(request, 'MunValuation/pending_approval.html', {'data':data, 'designation':designation})


def approval(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	pro_key = request.POST.get("pro_key")
	print(pro_key)
	TaxRegister1 = TaxRegister.objects.filter(properties_id=pro_key, security_tag=designation)
	for i in TaxRegister1:
		appro1 = i
		appro1.status = "Approved"
		appro1.save()

	TaxValue1 = TaxValue.objects.filter(properties_id=pro_key, security_tag=designation)
	for i in TaxValue1:
		appro2 = i
		appro2.v_status = "Approved"
		appro2.save()
	Tribunal1 = Tribunal.objects.filter(properties_id=pro_key, security_tag=designation)
	for i in Tribunal1:
		appro3 = i
		appro3.status = "Approved"
		appro3.save()
	CourtSchedule1 = CourtSchedule.objects.filter(properties_id=pro_key, security_tag=designation)
	for i in CourtSchedule1:
		appro4 = i
		appro4.status = "Approved"
		appro4.save()
	data = CourtSchedule.objects.filter(status="Pending", security_tag=designation)
	return render(request, 'MunValuation/pending_approval.html', {'data':data, 'designation':designation})


def certifications(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	data = TaxValue.objects.filter(v_status="Approved", security_tag=designation)
	return render(request, 'MunValuation/certificate_list.html', {'data':data, 'designation':designation})


def issue_certificate(request):
	user = request.user
	redirect_tag = UserProfile.objects.filter(user=user)
	for i in redirect_tag:
		redirect_office = i.user_office
		designation = i.office_tag
	return HttpResponse("Welcome")
